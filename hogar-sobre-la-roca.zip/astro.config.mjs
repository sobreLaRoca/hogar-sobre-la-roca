import { defineConfig } from 'astro/config';
export default defineConfig({
  site: 'https://www.hogarsobrelaroca.uy',
});